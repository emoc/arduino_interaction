var class_over_sample =
[
    [ "add", "class_over_sample.html#a9c9f4083b726ed046c97a91535486317", null ],
    [ "next", "class_over_sample.html#a413ca7de0dbf3d2afafd84aa75857442", null ]
];